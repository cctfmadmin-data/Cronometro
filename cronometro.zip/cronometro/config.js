// =====================================================================
//  CONFIGURAÇÃO — preenche com os dados do teu projeto Supabase
//  (Supabase → Project Settings → API → Project URL e anon public key)
//
//  Enquanto estes campos estiverem vazios, a app corre em MODO DEMO:
//  os tempos ficam guardados apenas neste browser (serve para testar).
// =====================================================================
window.CRONO_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",

  // Nome da prova por omissão. Pode ser trocado no link:
  //   operador.html?prova=Pista%20de%20Obstáculos
  //   index.html?prova=Pista%20de%20Obstáculos
  PROVA: "Geral"
};
