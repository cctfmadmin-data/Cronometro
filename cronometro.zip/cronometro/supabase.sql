-- =====================================================================
--  CRONÓMETRO + RANKING — base de dados (Supabase → SQL Editor → Run)
-- =====================================================================

-- 1) Tabela dos tempos ------------------------------------------------
create table if not exists public.tempos (
  id         bigint generated always as identity primary key,
  prova      text        not null default 'Geral',
  atleta     text        not null,
  tempo_ms   integer     not null check (tempo_ms > 0),
  criado_em  timestamptz not null default now(),
  client_id  uuid unique            -- evita duplicados quando a fila offline reenvia
);
create index if not exists tempos_prova_idx on public.tempos (prova);

alter table public.tempos enable row level security;

-- Qualquer pessoa pode LER (o ranking é público)
drop policy if exists "leitura publica" on public.tempos;
create policy "leitura publica" on public.tempos for select using (true);
-- Não há política de insert/update/delete: só se escreve através das funções abaixo (com PIN)

-- 2) PIN do operador (tabela fechada, ninguém a lê pelo browser) ------
create table if not exists public.config_privada (
  chave text primary key,
  valor text not null
);
alter table public.config_privada enable row level security;

insert into public.config_privada (chave, valor) values ('pin_operador', '1234')
on conflict (chave) do nothing;
-- >>> MUDA O PIN:  update public.config_privada set valor = 'O_TEU_PIN' where chave = 'pin_operador';

-- 3) Funções ----------------------------------------------------------
create or replace function public.verificar_pin(p_pin text)
returns boolean language sql security definer set search_path = public as $$
  select exists (select 1 from config_privada where chave = 'pin_operador' and valor = p_pin);
$$;

create or replace function public.registar_tempo(
  p_pin text, p_prova text, p_atleta text, p_tempo_ms integer, p_client_id uuid
) returns bigint language plpgsql security definer set search_path = public as $$
declare v_id bigint;
begin
  if not verificar_pin(p_pin) then raise exception 'PIN inválido'; end if;
  if coalesce(length(trim(p_atleta)), 0) = 0 then raise exception 'Nome do atleta vazio'; end if;
  if p_tempo_ms is null or p_tempo_ms <= 0 then raise exception 'Tempo inválido'; end if;

  insert into tempos (prova, atleta, tempo_ms, client_id)
  values (coalesce(nullif(trim(p_prova), ''), 'Geral'),
          regexp_replace(trim(p_atleta), '\s+', ' ', 'g'),
          p_tempo_ms, p_client_id)
  on conflict (client_id) do update set client_id = excluded.client_id
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.apagar_tempo(p_pin text, p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not verificar_pin(p_pin) then raise exception 'PIN inválido'; end if;
  delete from tempos where id = p_id;
end $$;

grant execute on function public.verificar_pin(text) to anon;
grant execute on function public.registar_tempo(text, text, text, integer, uuid) to anon;
grant execute on function public.apagar_tempo(text, bigint) to anon;

-- 4) Tempo real (o ranking atualiza sozinho) --------------------------
do $$ begin
  alter publication supabase_realtime add table public.tempos;
exception when duplicate_object then null; end $$;

-- 5) Limpar uma prova no fim (opcional — corre à mão quando quiseres)
-- delete from public.tempos where prova = 'Geral';
